import Model.Food;

import java.util.Scanner;

public class MyFoodMenu {

    public static void main(String[] args) {
        Food[] myMenu = new Food[5];

        myMenu[0] = new Food("001", "Nasi putih","Makanan", 5000);
        myMenu[1] = new Food("002", "Ayam Geprek","Makanan", 12000);
        myMenu[2] = new Food("003", "Tempe Penyet","Makanan", 4000);
        myMenu[3] = new Food("004", "Es Teh Manis","Minuman", 3000);
        myMenu[4] = new Food("005", "Lalapam","Makanan", 2000);

        for (int indexArrayMenu=0; indexArrayMenu<myMenu.length;indexArrayMenu++){
            myMenu[indexArrayMenu].PrintFoodMenu();
        }

        // --------------------------------------------------------------------------------------------
        // meminta input dari user kemudian memasukan ke model array myMenu2

        Food[] myMenu1 = new Food[3];
        int loop = 0;
        System.out.println("\nInput 3(Tiga) Data Makanan Baru");
        System.out.println("----------------------------------");
        for (int counter=0; counter<myMenu1.length;counter++){
            String kode;
            String nama;
            String kategori;
            int harga;
            loop++;

            Scanner userInput = new Scanner(System.in);
            System.out.println("\nInput Menu "+ loop);
            System.out.println("--------------------------");
            System.out.print("Masukan Kode Makanan = ");
            kode = userInput.nextLine();
            System.out.print("Masukan Nama Makanan = ");
            nama = userInput.nextLine();
            System.out.print("Masukan Kategori = ");
            kategori = userInput.nextLine();
            System.out.print("Masukan Harga = ");
            harga = userInput.nextInt();

            myMenu1[counter] = new Food(kode,nama,kategori,harga);
        }
        System.out.println("\n3(Tiga) Data Yang Diinput : ");
        System.out.println("---------------------------------");
        for (int counter=0;counter<myMenu1.length;counter++) {
            myMenu1[counter].PrintFoodMenu();
        }
    }
}


